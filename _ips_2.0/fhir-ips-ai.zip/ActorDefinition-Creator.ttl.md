# Creator (IPS) - TTL Representation - International Patient Summary Implementation Guide v2.0.0

## : Creator (IPS)

[Raw ttl](ActorDefinition-Creator.ttl) | [Download](ActorDefinition-Creator.ttl)

