# Server (IPS) - JSON Representation - International Patient Summary Implementation Guide v2.0.0

## : Server (IPS)

[Raw json](ActorDefinition-Server.json) | [Download](ActorDefinition-Server.json)

