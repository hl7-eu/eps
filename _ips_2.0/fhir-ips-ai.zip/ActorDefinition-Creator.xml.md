# Creator (IPS) - XML Representation - International Patient Summary Implementation Guide v2.0.0

## : Creator (IPS)

[Raw xml](ActorDefinition-Creator.xml) | [Download](ActorDefinition-Creator.xml)

