# Server (IPS) - TTL Representation - International Patient Summary Implementation Guide v2.0.0

## : Server (IPS)

[Raw ttl](ActorDefinition-Server.ttl) | [Download](ActorDefinition-Server.ttl)

