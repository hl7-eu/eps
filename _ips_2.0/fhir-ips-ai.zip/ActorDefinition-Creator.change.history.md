#  - International Patient Summary Implementation Guide v2.0.0

## : Creator (IPS) - Change History

History of changes for Creator ActorDefinition | downcase.

