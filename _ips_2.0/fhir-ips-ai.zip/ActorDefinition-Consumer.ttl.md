# Consumer (IPS) - TTL Representation - International Patient Summary Implementation Guide v2.0.0

## : Consumer (IPS)

[Raw ttl](ActorDefinition-Consumer.ttl) | [Download](ActorDefinition-Consumer.ttl)

