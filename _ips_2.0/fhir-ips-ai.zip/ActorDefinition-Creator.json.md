# Creator (IPS) - JSON Representation - International Patient Summary Implementation Guide v2.0.0

## : Creator (IPS)

[Raw json](ActorDefinition-Creator.json) | [Download](ActorDefinition-Creator.json)

