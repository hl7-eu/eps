# Server (IPS) - XML Representation - International Patient Summary Implementation Guide v2.0.0

## : Server (IPS)

[Raw xml](ActorDefinition-Server.xml) | [Download](ActorDefinition-Server.xml)

