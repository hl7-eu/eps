# Consumer (IPS) - JSON Representation - International Patient Summary Implementation Guide v2.0.0

## : Consumer (IPS)

[Raw json](ActorDefinition-Consumer.json) | [Download](ActorDefinition-Consumer.json)

