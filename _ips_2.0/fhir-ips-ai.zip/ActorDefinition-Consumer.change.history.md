#  - International Patient Summary Implementation Guide v2.0.0

## : Consumer (IPS) - Change History

History of changes for Consumer ActorDefinition | downcase.

