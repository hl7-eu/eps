#  - International Patient Summary Implementation Guide v2.0.0

## : Server (IPS) - Change History

History of changes for Server ActorDefinition | downcase.

