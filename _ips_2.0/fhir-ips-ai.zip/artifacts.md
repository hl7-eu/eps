# Artifacts Summary - International Patient Summary Implementation Guide v2.0.0

## Artifacts Summary

