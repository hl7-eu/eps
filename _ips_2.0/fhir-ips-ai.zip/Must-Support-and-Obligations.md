# Must Support and Obligations - International Patient Summary Implementation Guide v2.0.0

## Must Support and Obligations

### Must Support and Obligations

In the context of IPS, Obligations defines how an Actor ([Creator (IPS)](./ActorDefinition-Creator.md) or [Consumer (IPS)](ActorDefinition-Consumer.md)) must “support” a given element. All mustSupport elements in this publication are accompanied by an explicit obligation, which identifies structured expectations for a given actor. Obligations can be found in the formal view section of a resource as shown below for the IPS Procedure profile:

**Figure 5: Example of Obligations in IPS Procedure Profile**

![](Obligations.png)

Obligations may be different between the creator and consumer of an IPS document, and may also differ by profile and resource attributes. For all obligations, no data should be populated or processed in any way that conflicts with regional laws, regulations or policies. For additional context, see the [Security and Privacy Considerations](./Privacy-and-Security-Considerations.md) section of this implementation guide.

Because IPS is an implementation guide that may be localized to different jurisdictions and regions, one goal of obligations is that they may be inherited. Realm-specific implementation guides may apply additional obligations and/or provide additional guidance on the definition of mustSupport. However, they SHOULD identify and document these differences. For more information on obligations, see the [obligation extension](https://hl7.org/fhir/extensions/StructureDefinition-obligation.html) and the associated [obligation codes](https://hl7.org/fhir/extensions/ValueSet-obligation.html).

