# Creator (IPS) - International Patient Summary Implementation Guide v2.0.0

## ActorDefinition: Creator (IPS) 

### Test Plans

**No test plans are currently available for the Creator ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the Creator ActorDefinition.**

