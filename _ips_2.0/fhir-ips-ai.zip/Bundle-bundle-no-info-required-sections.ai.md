# Bundle - No Information in Required Sections - International Patient Summary Implementation Guide v2.0.0

## Example Bundle: Bundle - No Information in Required Sections

**Document Details**

Language: en

Profile: [Bundle (IPS)](StructureDefinition-Bundle-uv-ips.md)

Final Document at 2021-05-03 by [Organization Northcare, Thomas Road](Bundle-bundle-no-info-required-sections.md#Organization_d9b97b04-b606-4f07-baf2-7eb3dcae0a2a) for [James Judge Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)](Bundle-bundle-no-info-required-sections.md#Patient_AAA1234) 

-------

**Document Subject**

Language: en

James Judge Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)

-------

-------

**Document Content**

## Allergies and Intolerances

## Problem List

## Medication Summary

## Immunizations

-------

## Additional Resources Included in Document

-------

Entry 2 - fullUrl = https://terminz.azurewebsites.net/fhir/Patient/AAA1234

Resource Patient:

> 

Language: en

James Judge Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)
-------

-------

Entry 3 - fullUrl = https://terminz.azurewebsites.net/fhir/Organization/d9b97b04-b606-4f07-baf2-7eb3dcae0a2a

Resource Organization:

> 

Language: en

**identifier**:`https://standards.digital.health.nz/ns/hpi-facility-id`/F0K068-E**name**: Northcare, Thomas Road

-------

Entry 4 - fullUrl = https://terminz.azurewebsites.net/fhir/PractitionerRole/f54d8c90-aea2-46b0-8f7a-8683db78344e

Resource PractitionerRole:

> 

Language: en

**practitioner**:[Practitioner Dr Richard Kildare Kildare](Bundle-bundle-no-info-required-sections.md#Practitioner_19c24876-ccf8-45e7-8b66-462317e970f1)**code**:Doctor

-------

Entry 5 - fullUrl = https://terminz.azurewebsites.net/fhir/Practitioner/19c24876-ccf8-45e7-8b66-462317e970f1

Resource Practitioner:

> 

Language: en

**name**: Dr Richard Kildare Kildare**telecom**: ph: tel:+6478539191(Work)**address**: 12 Thomas Rd Huntingdon Hamilton 3211 NZ (work)

-------

Entry 6 - fullUrl = https://terminz.azurewebsites.net/fhir/Organization/70a756e3-20b3-4637-8601-a222983e295a

Resource Organization:

> 

Language: en

**identifier**:`https://standards.digital.health.nz/ns/psychotherapists-board-id`/F2N000-J**name**: NorthCare Pukete Road

-------

Entry 7 - fullUrl = https://terminz.azurewebsites.net/fhir/Immunization/4ab062b3-8843-4b98-af62-3d6d178a3772

Resource Immunization:

> 

Language: en

**status**: Completed**vaccineCode**:Influenza, split virus, trivalent, preservative**lotNumber**: B52b**expirationDate**: 2020-07-03**patient**:[James Judge Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)](Bundle-bundle-no-info-required-sections.md#Patient_AAA1234)**occurrence**: 2020-07-03**site**:Entire left upper arm**route**:Injection, intramuscular

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [Organization NorthCare Pukete Road](Bundle-bundle-no-info-required-sections.md#Organization_70a756e3-20b3-4637-8601-a222983e295a) |

### ProtocolApplieds

| | |
| :--- | :--- |
| - | **Series** |
| * | 45y (Eligible condition (Influenza)) |


-------

Entry 8 - fullUrl = https://terminz.azurewebsites.net/fhir/Immunization/bd6c6537-6c5a-4fa8-8d26-2b49377425a2

Resource Immunization:

> 

Language: en

**status**: Completed**vaccineCode**:Influenza, split virus, trivalent, preservative**lotNumber**: B52**expirationDate**: 2019-08-03**patient**:[James Judge Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)](Bundle-bundle-no-info-required-sections.md#Patient_AAA1234)**occurrence**: 2019-06-03**site**:Entire left upper arm**route**:Injection, intramuscular

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [Organization NorthCare Pukete Road](Bundle-bundle-no-info-required-sections.md#Organization_70a756e3-20b3-4637-8601-a222983e295a) |

### ProtocolApplieds

| | |
| :--- | :--- |
| - | **Series** |
| * | 45y (Eligible condition (Influenza)) |




## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-no-info-required-sections",
  "meta" : {
    "profile" : [
      "http://hl7.org/fhir/uv/ips/StructureDefinition/Bundle-uv-ips"
    ]
  },
  "language" : "en-NZ",
  "identifier" : {
    "system" : "urn:oid:2.16.724.4.8.10.200.10",
    "value" : "59f51f0b-2005-485c-858e-3d3ae9657287"
  },
  "type" : "document",
  "timestamp" : "2022-01-08T20:42:11.0607701+00:00",
  "entry" : [
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Composition/514af4c1-194d-48b4-8afe-7be09d3f895a",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "514af4c1-194d-48b4-8afe-7be09d3f895a",
        "meta" : {
          "versionId" : "1"
        },
        "language" : "en-NZ",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en-NZ\" lang=\"en-NZ\"><a name=\"Composition_514af4c1-194d-48b4-8afe-7be09d3f895a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition 514af4c1-194d-48b4-8afe-7be09d3f895a</b></p><a name=\"514af4c1-194d-48b4-8afe-7be09d3f895a\"> </a><a name=\"hc514af4c1-194d-48b4-8afe-7be09d3f895a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: 1; Language: en-NZ</p></div><p><b>identifier</b>: <code>urn:oid:2.16.840.1.113883.2.18.7.2</code>/59f51f0b-2005-485c-858e-3d3ae9657287</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 60591-5}\">Patient summary Document</span></p><p><b>date</b>: 2021-05-03</p><p><b>author</b>: <a href=\"Bundle-bundle-no-info-required-sections.html#Organization_d9b97b04-b606-4f07-baf2-7eb3dcae0a2a\">Organization Northcare, Thomas Road</a></p><p><b>title</b>: International Patient Summary</p><p><b>confidentiality</b>: normal</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Professional</td><td>2021-05-03</td><td><a href=\"Bundle-bundle-no-info-required-sections.html#PractitionerRole_f54d8c90-aea2-46b0-8f7a-8683db78344e\">PractitionerRole Doctor</a></td></tr></table><p><b>custodian</b>: <a href=\"Bundle-bundle-no-info-required-sections.html#Organization_70a756e3-20b3-4637-8601-a222983e295a\">Organization NorthCare Pukete Road</a></p><h3>RelatesTos</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Target[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>Transforms</td><td><code>urn:oid:2.16.840.1.113883.2.18.7.2</code>/59f51f0b-2005-485c-858e-3d3ae9657287</td></tr></table><h3>Events</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Period</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ActClass PCPR}\">care provision</span></td><td>?? --&gt; 2021-05-03</td></tr></table></div>"
        },
        "identifier" : {
          "system" : "urn:oid:2.16.840.1.113883.2.18.7.2",
          "value" : "59f51f0b-2005-485c-858e-3d3ae9657287"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "60591-5",
              "display" : "Patient summary Document"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/AAA1234"
        },
        "date" : "2021-05-03",
        "author" : [
          {
            "reference" : "Organization/d9b97b04-b606-4f07-baf2-7eb3dcae0a2a"
          }
        ],
        "title" : "International Patient Summary",
        "confidentiality" : "N",
        "attester" : [
          {
            "mode" : "professional",
            "time" : "2021-05-03",
            "party" : {
              "reference" : "PractitionerRole/f54d8c90-aea2-46b0-8f7a-8683db78344e"
            }
          }
        ],
        "custodian" : {
          "reference" : "Organization/70a756e3-20b3-4637-8601-a222983e295a"
        },
        "relatesTo" : [
          {
            "code" : "transforms",
            "targetIdentifier" : {
              "system" : "urn:oid:2.16.840.1.113883.2.18.7.2",
              "value" : "59f51f0b-2005-485c-858e-3d3ae9657287"
            }
          }
        ],
        "event" : [
          {
            "code" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActClass",
                    "code" : "PCPR"
                  }
                ]
              }
            ],
            "period" : {
              "end" : "2021-05-03"
            }
          }
        ],
        "section" : [
          {
            "title" : "Allergies and Intolerances",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "48765-2",
                  "display" : "Allergies and adverse reactions Document"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en-NZ\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-NZ\">There is no information available regarding the subject's allergies.</div>"
            },
            "emptyReason" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                  "code" : "unavailable",
                  "display" : "Unavailable"
                }
              ],
              "text" : "No information available"
            }
          },
          {
            "title" : "Problem List",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "11450-4",
                  "display" : "Problem list - Reported"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en-NZ\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-NZ\">There is no information available about the subject's health problems or disabilities.</div>"
            },
            "emptyReason" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                  "code" : "unavailable",
                  "display" : "Unavailable"
                }
              ],
              "text" : "No information available"
            }
          },
          {
            "title" : "Medication Summary",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "10160-0",
                  "display" : "History of Medication use Narrative"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en-NZ\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-NZ\">There is no information available about the subject's medication use or administration.</div>"
            },
            "emptyReason" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
                  "code" : "unavailable",
                  "display" : "Unavailable"
                }
              ],
              "text" : "No information available"
            }
          },
          {
            "title" : "Immunizations",
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "11369-6",
                  "display" : "History of Immunization note"
                }
              ]
            },
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"en-NZ\" xmlns=\"http://www.w3.org/1999/xhtml\"><table><thead><tr><th>Vaccine</th><th>Date</th><th>Seq</th><th>Route</th><th>Site</th><th>Indication</th><th>Status</th></tr></thead><tbody><tr><td>Influenza</td><td>03/07/2020</td><td>2</td><td>Injection, intramuscular</td><td>Entire left upper arm</td><td>Eligible condition (Influenza)</td><td>completed</td></tr><tr><td>Influenza</td><td>03/06/2019</td><td>1</td><td>Injection, intramuscular</td><td>Entire left upper arm</td><td>Eligible condition (Influenza)</td><td>completed</td></tr></tbody></table></div>"
            },
            "entry" : [
              {
                "reference" : "Immunization/4ab062b3-8843-4b98-af62-3d6d178a3772"
              },
              {
                "reference" : "Immunization/bd6c6537-6c5a-4fa8-8d26-2b49377425a2"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Patient/AAA1234",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "AAA1234",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_AAA1234\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient AAA1234</b></p><a name=\"AAA1234\"> </a><a name=\"hcAAA1234\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">James Judge  Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-MaritalStatus M}\">Married</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: tel:+6478532279(Home)</li><li>Bleak House 3 Worcester Drive Rototuna North Hamilton 3210 NZ (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Language spoken\">Language:</td><td colspan=\"3\"><span title=\"Codes:{urn:ietf:bcp:47 en-NZ}\">English (Region=New Zealand)</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Nominated Contact: family member\">family member:</td><td colspan=\"3\"><ul><li>Natural mother mother </li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Nominated Contact: unrelated friend\">unrelated friend:</td><td colspan=\"3\"><ul><li>Peter Rabbit Rabbit </li><li>9 Worcester Drive Rototuna Hamilton 3210 NZ (home)</li><li>ph: 07 853 9191(Home)</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "system" : "https://standards.digital.health.nz/ns/nhi-id",
            "value" : "AAA1234"
          }
        ],
        "name" : [
          {
            "use" : "usual",
            "family" : "Judge",
            "given" : ["James"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+6478532279",
            "use" : "home"
          }
        ],
        "gender" : "male",
        "birthDate" : "1985-04-25",
        "address" : [
          {
            "use" : "home",
            "type" : "physical",
            "line" : ["Bleak House", "3 Worcester Drive", "Rototuna North"],
            "city" : "Hamilton",
            "postalCode" : "3210",
            "country" : "NZ"
          }
        ],
        "maritalStatus" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
              "code" : "M",
              "display" : "Married"
            }
          ]
        },
        "contact" : [
          {
            "relationship" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
                    "code" : "FAMMEMB",
                    "display" : "family member"
                  },
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
                    "code" : "N",
                    "display" : "Next-of-Kin"
                  }
                ]
              }
            ],
            "name" : {
              "use" : "usual",
              "family" : "mother",
              "given" : ["Natural", "mother"]
            }
          },
          {
            "relationship" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
                    "code" : "FRND",
                    "display" : "unrelated friend"
                  },
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v2-0131",
                    "code" : "C",
                    "display" : "Emergency Contact"
                  }
                ]
              }
            ],
            "name" : {
              "use" : "usual",
              "family" : "Rabbit",
              "given" : ["Peter", "Rabbit"]
            },
            "telecom" : [
              {
                "system" : "phone",
                "value" : "07 853 9191",
                "use" : "home"
              }
            ],
            "address" : {
              "use" : "home",
              "type" : "physical",
              "line" : ["9 Worcester Drive", "Rototuna"],
              "city" : "Hamilton",
              "postalCode" : "3210",
              "country" : "NZ"
            }
          }
        ],
        "communication" : [
          {
            "language" : {
              "coding" : [
                {
                  "system" : "urn:ietf:bcp:47",
                  "code" : "en-NZ"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Organization/d9b97b04-b606-4f07-baf2-7eb3dcae0a2a",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "d9b97b04-b606-4f07-baf2-7eb3dcae0a2a",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_d9b97b04-b606-4f07-baf2-7eb3dcae0a2a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization d9b97b04-b606-4f07-baf2-7eb3dcae0a2a</b></p><a name=\"d9b97b04-b606-4f07-baf2-7eb3dcae0a2a\"> </a><a name=\"hcd9b97b04-b606-4f07-baf2-7eb3dcae0a2a\"> </a><p><b>identifier</b>: <code>https://standards.digital.health.nz/ns/hpi-facility-id</code>/F0K068-E</p><p><b>name</b>: Northcare, Thomas Road</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://standards.digital.health.nz/ns/hpi-facility-id",
            "value" : "F0K068-E"
          }
        ],
        "name" : "Northcare, Thomas Road"
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/PractitionerRole/f54d8c90-aea2-46b0-8f7a-8683db78344e",
      "resource" : {
        "resourceType" : "PractitionerRole",
        "id" : "f54d8c90-aea2-46b0-8f7a-8683db78344e",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_f54d8c90-aea2-46b0-8f7a-8683db78344e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole f54d8c90-aea2-46b0-8f7a-8683db78344e</b></p><a name=\"f54d8c90-aea2-46b0-8f7a-8683db78344e\"> </a><a name=\"hcf54d8c90-aea2-46b0-8f7a-8683db78344e\"> </a><p><b>practitioner</b>: <a href=\"Bundle-bundle-no-info-required-sections.html#Practitioner_19c24876-ccf8-45e7-8b66-462317e970f1\">Practitioner Dr Richard Kildare Kildare </a></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 158965000}\">Doctor</span></p></div>"
        },
        "practitioner" : {
          "reference" : "Practitioner/19c24876-ccf8-45e7-8b66-462317e970f1"
        },
        "code" : [
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "158965000",
                "display" : "Doctor"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Practitioner/19c24876-ccf8-45e7-8b66-462317e970f1",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "19c24876-ccf8-45e7-8b66-462317e970f1",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_19c24876-ccf8-45e7-8b66-462317e970f1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 19c24876-ccf8-45e7-8b66-462317e970f1</b></p><a name=\"19c24876-ccf8-45e7-8b66-462317e970f1\"> </a><a name=\"hc19c24876-ccf8-45e7-8b66-462317e970f1\"> </a><p><b>name</b>: Dr Richard Kildare Kildare </p><p><b>telecom</b>: ph: tel:+6478539191(Work)</p><p><b>address</b>: 12 Thomas Rd Huntingdon Hamilton 3211 NZ (work)</p></div>"
        },
        "name" : [
          {
            "use" : "usual",
            "family" : "Kildare",
            "given" : ["Dr", "Richard", "Kildare"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "tel:+6478539191",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "use" : "work",
            "type" : "physical",
            "line" : ["12 Thomas Rd", "Huntingdon"],
            "city" : "Hamilton",
            "postalCode" : "3211",
            "country" : "NZ"
          }
        ]
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Organization/70a756e3-20b3-4637-8601-a222983e295a",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "70a756e3-20b3-4637-8601-a222983e295a",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_70a756e3-20b3-4637-8601-a222983e295a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization 70a756e3-20b3-4637-8601-a222983e295a</b></p><a name=\"70a756e3-20b3-4637-8601-a222983e295a\"> </a><a name=\"hc70a756e3-20b3-4637-8601-a222983e295a\"> </a><p><b>identifier</b>: <code>https://standards.digital.health.nz/ns/psychotherapists-board-id</code>/F2N000-J</p><p><b>name</b>: NorthCare Pukete Road</p></div>"
        },
        "identifier" : [
          {
            "system" : "https://standards.digital.health.nz/ns/psychotherapists-board-id",
            "value" : "F2N000-J"
          }
        ],
        "name" : "NorthCare Pukete Road"
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Immunization/4ab062b3-8843-4b98-af62-3d6d178a3772",
      "resource" : {
        "resourceType" : "Immunization",
        "id" : "4ab062b3-8843-4b98-af62-3d6d178a3772",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_4ab062b3-8843-4b98-af62-3d6d178a3772\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization 4ab062b3-8843-4b98-af62-3d6d178a3772</b></p><a name=\"4ab062b3-8843-4b98-af62-3d6d178a3772\"> </a><a name=\"hc4ab062b3-8843-4b98-af62-3d6d178a3772\"> </a><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/cvx 141}\">Influenza, split virus, trivalent, preservative</span></p><p><b>patient</b>: <a href=\"Bundle-bundle-no-info-required-sections.html#Patient_AAA1234\">James Judge  Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)</a></p><p><b>occurrence</b>: 2020-07-03</p><p><b>lotNumber</b>: B52b</p><p><b>expirationDate</b>: 2020-07-03</p><p><b>site</b>: <span title=\"Codes:{http://snomed.info/sct 72098002}\">Entire left upper arm</span></p><p><b>route</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration IM}\">Injection, intramuscular</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundle-no-info-required-sections.html#Organization_70a756e3-20b3-4637-8601-a222983e295a\">Organization NorthCare Pukete Road</a></td></tr></table><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Series</b></td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>45y (Eligible condition (Influenza))</td><td>2</td></tr></table></div>"
        },
        "status" : "completed",
        "vaccineCode" : {
          "coding" : [
            {
              "system" : "http://hl7.org/fhir/sid/cvx",
              "code" : "141",
              "display" : "Influenza, split virus, trivalent, preservative"
            }
          ]
        },
        "patient" : {
          "reference" : "Patient/AAA1234"
        },
        "occurrenceDateTime" : "2020-07-03",
        "lotNumber" : "B52b",
        "expirationDate" : "2020-07-03",
        "site" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "72098002",
              "display" : "Entire left upper arm"
            }
          ]
        },
        "route" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration",
              "code" : "IM",
              "display" : "Injection, intramuscular"
            }
          ]
        },
        "performer" : [
          {
            "actor" : {
              "reference" : "Organization/70a756e3-20b3-4637-8601-a222983e295a"
            }
          }
        ],
        "protocolApplied" : [
          {
            "series" : "45y (Eligible condition (Influenza))",
            "doseNumberPositiveInt" : 2
          }
        ]
      }
    },
    {
      "fullUrl" : "https://terminz.azurewebsites.net/fhir/Immunization/bd6c6537-6c5a-4fa8-8d26-2b49377425a2",
      "resource" : {
        "resourceType" : "Immunization",
        "id" : "bd6c6537-6c5a-4fa8-8d26-2b49377425a2",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_bd6c6537-6c5a-4fa8-8d26-2b49377425a2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization bd6c6537-6c5a-4fa8-8d26-2b49377425a2</b></p><a name=\"bd6c6537-6c5a-4fa8-8d26-2b49377425a2\"> </a><a name=\"hcbd6c6537-6c5a-4fa8-8d26-2b49377425a2\"> </a><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://hl7.org/fhir/sid/cvx 141}\">Influenza, split virus, trivalent, preservative</span></p><p><b>patient</b>: <a href=\"Bundle-bundle-no-info-required-sections.html#Patient_AAA1234\">James Judge  Male, DoB: 1985-04-25 ( https://standards.digital.health.nz/ns/nhi-id#AAA1234)</a></p><p><b>occurrence</b>: 2019-06-03</p><p><b>lotNumber</b>: B52</p><p><b>expirationDate</b>: 2019-08-03</p><p><b>site</b>: <span title=\"Codes:{http://snomed.info/sct 72098002}\">Entire left upper arm</span></p><p><b>route</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration IM}\">Injection, intramuscular</span></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-bundle-no-info-required-sections.html#Organization_70a756e3-20b3-4637-8601-a222983e295a\">Organization NorthCare Pukete Road</a></td></tr></table><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Series</b></td><td><b>DoseNumber[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>45y (Eligible condition (Influenza))</td><td>1</td></tr></table></div>"
        },
        "status" : "completed",
        "vaccineCode" : {
          "coding" : [
            {
              "system" : "http://hl7.org/fhir/sid/cvx",
              "code" : "141",
              "display" : "Influenza, split virus, trivalent, preservative"
            }
          ]
        },
        "patient" : {
          "reference" : "Patient/AAA1234"
        },
        "occurrenceDateTime" : "2019-06-03",
        "lotNumber" : "B52",
        "expirationDate" : "2019-08-03",
        "site" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "72098002",
              "display" : "Entire left upper arm"
            }
          ]
        },
        "route" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration",
              "code" : "IM",
              "display" : "Injection, intramuscular"
            }
          ]
        },
        "performer" : [
          {
            "actor" : {
              "reference" : "Organization/70a756e3-20b3-4637-8601-a222983e295a"
            }
          }
        ],
        "protocolApplied" : [
          {
            "series" : "45y (Eligible condition (Influenza))",
            "doseNumberPositiveInt" : 1
          }
        ]
      }
    }
  ]
}

```
